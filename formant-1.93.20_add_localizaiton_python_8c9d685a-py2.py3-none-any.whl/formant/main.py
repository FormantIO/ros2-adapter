import json
from sdk.cloud.v1 import Client as FormantClient
import os

if __name__ == "__main__":
    # to authenticate set FORMANT_EMAIL and FORMANT_PASSWORD
    # environment variables for an existing service account

    """Example query params (only start and end time are required):
    {
        start: "2021-01-01T01:00:00.000Z",
        end: "2021-01-01T02:00:00.000Z",
        deviceIds: ["99e8ee37-0a27-4a11-bba2-521facabefa3"],
        names: ["engine_temp"],
        types: ["numeric"],
        tags: {"location":["sf","la"]},
        notNames: ["speed"],
    }
    """
    os.environ["FORMANT_EMAIL"] = "support+canvas@figure.works"
    os.environ["FORMANT_PASSWORD"] = "OWuOteE2CrTKjiQe"

    fclient = FormantClient()

    result = fclient.query(
        {
            "start": "2022-02-01T00:00:00.000+00:00",
            "end": "2022-02-02T00:00:00.000+00:00",
            "types": ["health"],
        }
    )
    flat_1 = [x[0] for stream_data in result["items"] for x in stream_data["points"]]
    ma = max(flat_1)
    mi = min(flat_1)
    l = len(flat_1)
    print("Small Window:")
    print(ma)
    print(mi)
    print(l)

    # query by tags
    result = fclient.query(
        {
            "start": "2022-01-01T00:00:00.000+00:00",
            "end": "2022-07-10T17:14:34.740+00:00",
            "types": ["health"],
        }
    )
    flat_2 = [x[0] for stream_data in result["items"] for x in stream_data["points"]]
    filtered_2 = list(filter(lambda stamp: stamp <= ma and stamp >= mi, flat_2))
    ma_2 = max(filtered_2)
    mi_2 = min(filtered_2)
    l_2 = len(filtered_2)
    print("Large Window:")
    print(ma_2)
    print(mi_2)
    print(l_2)
